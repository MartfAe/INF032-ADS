print("O resto da divisão é:", 10 % 3)
