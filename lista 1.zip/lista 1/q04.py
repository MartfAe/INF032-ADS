print("A área do círculo é:", 3.141592*2*2)
