numInvertido = (((123 % 10)*100) + (((123//10) % 10)*10) + 123//100)
print("Número invertido:", numInvertido)
