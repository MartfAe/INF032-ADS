distancia = 65*1000
tempo = ((3*3600) + (23*60) + 17)
print("Sua velocidade é de:", distancia/tempo, "m/s")
