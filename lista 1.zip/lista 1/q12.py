volumeBolinha = ((4/3)*3.14*(1.2**3))
volumePoteOcupavel = ((15*10*13)*0.74)
print("Quantidade de bolinhas:", volumePoteOcupavel/volumeBolinha)
