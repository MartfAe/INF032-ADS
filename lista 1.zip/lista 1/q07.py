sen = 0.9848
cos = 0.1736
print("Seno:", sen)
print("Cosseno:", cos)
print("Tangente:", sen/cos)
print("Secante:", 1/cos)
print("Cossecante:", 1/sen)
print("Cotangente:", (1/(sen/cos)))
