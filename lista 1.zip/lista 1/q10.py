a = 5
b = 12

a, b = b, a
print(a, b)
