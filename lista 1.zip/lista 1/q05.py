print("Tenho um total de:", ((3*3600)+(23*60)+17))
