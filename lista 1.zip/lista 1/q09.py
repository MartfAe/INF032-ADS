
print("Perímetro:", ((10*2)+(5*2)))
print("Área:", (10*5))
print("Diagonal:", (((10**2)+(5**2))**0.5))
