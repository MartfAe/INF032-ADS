print("Devinir só pode faltar:", 32*0.25, "aulas")
