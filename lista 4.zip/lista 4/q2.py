semana = {
	"segunda": ["inf028", "inf006"],
	"terça": ["inf028"],
	"quarta": ["inf006", "inf029"],
	"quinta": ["inf006"],
	"sexta": ["inf032", "inf029"],
	"sabado": [],
	"domingo": []
}
