filme = {"HarryPotter": {"Voldemort": 2001},
         "StarWars": {"DarthVader": 1977},
         "ReiLeão": {"Scar": 1994},
         "AvengersUltimato": {"Thanos": 2019},
         "Batman": {"Coringa": 2008}
        }

