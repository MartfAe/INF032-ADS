camisa = {"Anna": "preto", "Cauan": "branco", 
          "Joao": "cinza", "Vitor": "cinza", 
          "Rafael": "preto"}

