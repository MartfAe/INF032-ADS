d={"nome": "Ana Emília Lobo e Martfeld", "idade": 22, "telefone": "71 992911999", "endereço": "Rua Rui Barbosa, 05, Cachoeira, Bahia"}

print(d["nome"])