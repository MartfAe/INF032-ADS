

agenda = {"051032587-00":
        {"nome": "Ana",
         "idade": 22,
         "telefone": "71 992911999",
        },
        "025365785-99":{
            "nome": "João",
            "idade": 25,
            "telefone": "25 96575222",
        },
        "634056255-01":{
            "nome": "Maria",
            "idade": 30,
            "telefone": "7534253148",
        },
        "123456789-00":{
            "nome": "Laura",
            "idade": 12,
            "telefone": "25 55223244",
        },
        "021584377-63":{
            "nome": "Lais",
            "idade": 15,
            "telefone": "75991156151",
        }
    }

print(agenda["051032587-00"])